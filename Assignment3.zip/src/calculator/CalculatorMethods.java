package calculator;

/**
 * The CalculatorMethods class provides the basic functionality for a calculator,
 * including handling of arithmetic operations, overflow checking, and result retrieval.
 * This class is intended to be extended by specific calculator implementations.
 */
public abstract class CalculatorMethods implements Calculator {
  protected StringBuilder input1;  // holds the first number
  protected StringBuilder input2;  // holds the second number
  protected char opp1; // holds the operator
  protected boolean oppTaken; // checks to see if there is already an operator
  protected boolean inputTaken; // indicates if the input is taken
  protected boolean previouslyCalculated; // indicates if a previous operation has been performed
  protected StringBuilder before;


  /**
   * Constructs a new CalculatorMethods instance with default settings.
   */
  public CalculatorMethods() {
    this.input1 = new StringBuilder();
    this.input2 = new StringBuilder();
    this.opp1 = ' ';
    this.oppTaken = false;
    this.inputTaken = false;
    this.previouslyCalculated = false;
    this.before = new StringBuilder();
  }

  //helper to see if we can add the number
  protected void number(char in) {
    if (!inputTaken) {
      if (input1.length() == 0 && oppTaken) {
        throw new IllegalArgumentException("Need a number first.");
      }
      input1.append(in);
      checkOverflow(input1);
    } else {
      input2.append(in);
      checkOverflow(input2);
    }
  }

  //helper to see if we can add the opperator
  protected void opp(char in) {
    if (input1.length() == 0) {
      throw new IllegalArgumentException("Need a number first.");
    }
    if (inputTaken) {
      calculate();
    }
    if (oppTaken) {
      throw new IllegalArgumentException("Need to proccess, before input.");
    }
    opp1 = in;
    oppTaken = true;
    inputTaken = true;
  }

  //calculates the numbers
  protected void calculate() {
    if (oppTaken && input2.length() > 0) {
      long num1 = Long.parseLong(input1.toString());
      long num2 = Long.parseLong(input2.toString());
      long tempResult = 0;

      switch (opp1) {
        case '+':
          tempResult = num1 + num2;
          break;
        case '-':
          tempResult = num1 - num2;
          break;
        case '*':
          tempResult = num1 * num2;
          break;
        default:
          throw new IllegalArgumentException("Invalid input.");
      }
      if (tempResult > Integer.MAX_VALUE || tempResult < Integer.MIN_VALUE) {
        tempResult = 0;
      }

      input1.setLength(0);
      input1.append(tempResult);
      before = input2;
      input2 = new StringBuilder();
      oppTaken = false;
      inputTaken = false;
    }
  }


  //gets the current result.
  @Override
  public String getResult() {
    if (!oppTaken) {
      return input1.toString();
    } else if (input2.length() == 0) {
      return input1.toString() + opp1;
    } else {
      return input1.toString() + opp1 + input2.toString();
    }
  }

  //checks for overflow
  protected void checkOverflow(StringBuilder number) {
    if (number.length() > 10) {
      number.setLength(10);
      throw new IllegalArgumentException("Operand overflow");
    }
  }

  //helper to clear the calculator when prompted
  protected void clearCalc() {
    this.input1 = new StringBuilder();
    this.input2 = new StringBuilder();
    this.opp1 = ' ';
    this.oppTaken = false;
    this.inputTaken = false;
    this.previouslyCalculated = false;
  }
}
