package calculator;

/**
 * The {@code Calculator} interface represents a contract for a simple calculator
 * that can process character inputs and retrieve the current result of the operations.
 * Implementations of this interface should handle basic arithmetic operations and manage
 * the state of the calculator.
 */
public interface Calculator {

  /**
   * Processes a single character input, which can be a digit, operator, or control character.
   * Valid inputs include:
   * <ul>
   *   <li>Digits ('0' - '9')</li>
   *   <li>Operators ('+', '-', '*')</li>
   *   <li>Equals sign ('=') to produce the result</li>
   *   <li>Clear ('C') to reset the calculator</li>
   * </ul>
   *
   * @param in the character input
   * @return the current instance of the {@code Calculator}, allowing for method chaining
   * @throws IllegalArgumentException if the input character is invalid
   */
  Calculator input(char in);

  /**
   * Retrieves the current result of the calculator's operations as a {@code String}.
   * The result represents the outcome of the processed inputs and current state of the calculator.
   *
   * @return the result as a {@code String}
   */
  String getResult();


}
