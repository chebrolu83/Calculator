package calculator;

/**
 * The SmartCalculator class extends CalculatorMethods to provide advanced handling of
 * arithmetic expressions, including support for multiple equal signs and operators.
 */
public class SmartCalculator extends CalculatorMethods {
  protected boolean multipleEquals; //sees if there are multiple equal signs in a row
  protected boolean multipleSigns; //sees if there are more than one signs
  protected char equals;


  /**
   * Constructs a new SmartCalculator with default settings for the fields. It also calls
   * the constructor from the abstract class.
   */
  public SmartCalculator() {
    super();
    this.multipleEquals = false;
    this.multipleSigns = false;
    this.equals = ' ';
  }

  @Override
  public Calculator input(char input) {
    if (Character.isDigit(input) && previouslyCalculated) {
      previouslyCalculated = false;
      multipleEquals = false;
      clearCalc();
      number(input); //delegates to the helper
    } else if ((input == '+' || input == '-' || input == '*') && previouslyCalculated) {
      previouslyCalculated = false;
      multipleEquals = false;
      opp(input);
    } else if (Character.isDigit(input)) {
      number(input);
    } else if (input == '+' || input == '-' || input == '*') {
      opp(input);
    } else if (input == '=') {
      previouslyCalculated = true;
      processEquals();
    } else if (input == 'C') {
      clearCalc();
    } else {
      throw new IllegalArgumentException("Invalid input.");
    }
    return this;
  }

  //helper to set an opperand
  @Override
  protected void opp(char input) {
    if (input1.length() == 0) {
      if (input == '+') {
        return;
      } else {
        throw new IllegalArgumentException("Invalid input.");
      }
    }
    if (inputTaken) {
      calculate();
      multipleSigns = false;
    }
    if (oppTaken) {
      multipleSigns = true;
    }
    equals = input;
    opp1 = input;
    oppTaken = true;
    inputTaken = true;
  }

  //helper for the equals calculation
  private void processEquals() {
    if (oppTaken && input2.length() == 0) {
      if (!multipleEquals) {
        input2.append(input1.toString());
        multipleEquals = true;
      } else {
        input2 = before;
      }
    } else if (!oppTaken && previouslyCalculated) {
      input2 = before;
      opp1 = equals;
      oppTaken = true;
    }
    calculate();
  }

}
