package calculator;

/**
 * The {@code SimpleCalculator} is a simple calculator that supports basic arithmetic operations
 * on whole numbers. It processes inputs one character at a time.
 */
public class SimpleCalculator extends CalculatorMethods {

  /**
   * Constructs a new {@code SimpleCalculator} instance with initial state.
   * The calculator starts with no inputs and no operator set.
   */
  public SimpleCalculator() {
    super();
  }


  @Override
  public Calculator input(char input) {
    if (Character.isDigit(input) && previouslyCalculated) {
      previouslyCalculated = false;
      input1.setLength(0);
      number(input); //delegate to helper
    } else if ((input == '+' || input == '-' || input == '*') && previouslyCalculated) {
      previouslyCalculated = false;
      opp(input); //delegate to helper
    } else if (Character.isDigit(input)) {
      number(input);
    } else if (input == '+' || input == '-' || input == '*') {
      opp(input);
    } else if (input == '=') {
      previouslyCalculated = true;
      calculate();
    } else if (input == 'C') {
      clearCalc();
    } else {
      throw new IllegalArgumentException("Invalid input.");
    }
    return this;
  }


}
