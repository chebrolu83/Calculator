package calculator;

import static org.junit.Assert.assertEquals;


import org.junit.Test;


/**
 * The SmartCalculatorTest class contains unit tests for the SmartCalculator class.
 * These tests ensure the calculator performs arithmetic operations correctly
 * and handles various input scenarios.
 */
public class SmartCalculatorTest {

  @Test
  public void testBasicOperation() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('4').input('+').input('6').input('=');
    assertEquals("10", calculator.getResult());
  }

  @Test
  public void testOperatorSequence() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('4').input('+').input('6').input('*').input('3').input('=');
    assertEquals("30", calculator.getResult());
  }

  @Test
  public void testClearInput() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('4').input('+').input('6').input('C');
    assertEquals("", calculator.getResult());
  }

  @Test
  public void testIncompleteExpression() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('4').input('+').input('=');
    assertEquals("8", calculator.getResult());
  }

  @Test
  public void testInitialOperator() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('+').input('4').input('6').input('=');
    assertEquals("46 ", calculator.getResult());
  }

  @Test
  public void testRepeatedEquals() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('4').input('+').input('6').input('=').input('=');
    assertEquals("16", calculator.getResult());
  }

  @Test
  public void testMultiplicationOverflow() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('8').input('8').input('8').input('8').input('8').input('8').input('*')
            .input('8').input('8').input('8').input('8').input('8').input('8').input('=');
    assertEquals("0", calculator.getResult());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testExceedingOperandLength() {
    SmartCalculator calculator = new SmartCalculator();
    for (int i = 0; i < 11; i++) {
      calculator.input('8');
    }
  }

  @Test
  public void testDoubleOperators() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('4').input('+').input('+').input('6').input('=');
    assertEquals("10", calculator.getResult());
  }

  @Test
  public void testTripleOperators() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('4').input('+').input('+').input('+').input('6').input('=');
    assertEquals("10", calculator.getResult());
  }

  @Test
  public void testInitialOperandResult() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('4');
    assertEquals("4", calculator.getResult());
  }

  @Test
  public void testOperatorInputResult() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('4').input('+');
    assertEquals("4+", calculator.getResult());
  }

  @Test
  public void testResultWithSecondOperand() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('4').input('+').input('6');
    assertEquals("4+6", calculator.getResult());
  }

  @Test
  public void testResultAfterEqualsThenOperator() {
    SmartCalculator calculator = new SmartCalculator();
    calculator.input('4').input('+').input('6').input('=').input('+');
    assertEquals("10+", calculator.getResult());
  }
}
