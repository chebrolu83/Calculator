package calculator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Test;

/**
 * The SimpleCalculatorTest class contains unit tests for the SimpleCalculator class.
 * These tests ensure the calculator performs arithmetic operations correctly
 * and handles various input scenarios.
 */
public class SimpleCalculatorTest {

  @Test
  public void testBasicAddition() {
    SimpleCalculator calculator = new SimpleCalculator();
    calculator.input('4').input('+').input('5').input('=');
    assertEquals("9", calculator.getResult());
  }

  @Test
  public void testMultipleOperatorsOrder() {
    SimpleCalculator calculator = new SimpleCalculator();
    calculator.input('4').input('+').input('5').input('*').input('3').input('=');
    assertEquals("27", calculator.getResult());
  }

  @Test
  public void testClearInput() {
    SimpleCalculator calculator = new SimpleCalculator();
    calculator.input('4').input('+').input('5').input('C');
    assertEquals("", calculator.getResult());
  }

  @Test
  public void testIncompleteExpression() {
    SimpleCalculator calculator = new SimpleCalculator();
    calculator.input('4').input('+').input('=');
    assertEquals("4+", calculator.getResult());
  }

  @Test
  public void testStartsWithPlusOperator() {
    SimpleCalculator calculator = new SimpleCalculator();
    try {
      calculator.input('+').input('4').input('5').input('=');
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      // Expected exception
    }
  }

  @Test
  public void testRepeatedEquals() {
    SimpleCalculator calculator = new SimpleCalculator();
    calculator.input('4').input('+').input('5').input('=').input('=');
    assertEquals("9", calculator.getResult());
  }

  @Test
  public void testLargeNumberMultiplicationOverflow() {
    SimpleCalculator calculator = new SimpleCalculator();
    calculator.input('9').input('9').input('9').input('9').input('9').input('9').input('*')
            .input('9').input('9').input('9').input('9').input('9').input('9').input('=');
    assertEquals("0", calculator.getResult());
  }

  @Test
  public void testExceedingOperandLength() {
    SimpleCalculator calculator = new SimpleCalculator();
    try {
      for (int i = 0; i < 11; i++) {
        calculator.input('8');
      }
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      // Expected exception
    }
  }

  @Test
  public void testDoubleOperators() {
    SimpleCalculator calculator = new SimpleCalculator();
    try {
      calculator.input('4').input('+').input('+').input('5').input('=');
      fail("Expected IllegalArgumentException");
    } catch (IllegalArgumentException e) {
      // Expected exception
    }
  }

  @Test
  public void testFirstOperandResult() {
    SimpleCalculator calculator = new SimpleCalculator();
    calculator.input('4');
    assertEquals("4", calculator.getResult());
  }

  @Test
  public void testResultAfterOperatorInput() {
    SimpleCalculator calculator = new SimpleCalculator();
    calculator.input('4').input('+');
    assertEquals("4+", calculator.getResult());
  }

  @Test
  public void testResultWithSecondOperand() {
    SimpleCalculator calculator = new SimpleCalculator();
    calculator.input('4').input('+').input('5');
    assertEquals("4+5", calculator.getResult());
  }

  @Test
  public void testResultAfterEqualsThenOperator() {
    SimpleCalculator calculator = new SimpleCalculator();
    calculator.input('4').input('+').input('5').input('=').input('+');
    assertEquals("9+", calculator.getResult());
  }
}
